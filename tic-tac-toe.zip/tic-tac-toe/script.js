// Tic Tac Toe
//
// Step 2 will start here:
// - Gameboard factory (holds the board array, wrapped in an IIFE — only one board needed)
// - Player factory (creates player objects with a name + marker)
// - GameController factory (controls turns, win/tie checks, wrapped in an IIFE)
// - DisplayController (handles rendering to the DOM — built after console logic works)
